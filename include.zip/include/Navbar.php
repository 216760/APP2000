




<a class="navbar-brand" href="file:///Users/henriksj/OneDrive%20-%20USN/Proskjet%20webapp%20gruppe%202/Forside.html"><img src="img/Logo.png"></a>
			
			<button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarResponsive">
				<span class="navbar-toggler-icon"></span>
			</button>


			<div class="collapse navbar-collapse " id="navbarResponsive">
				
				<ul class="navbar-nav ml-auto">
					<li class="nav-item dropdown">
						<a class="nav-link dropdown-toggle" data-toggle="dropdown" data-target="dropdown_target" href="#"> Abonnenter
							<span class="caret"></span>
						</a>
						<div class="dropdown-menu" aria-labelledby="dropdown_target">
							<a class="dropdown-item" href="file:///Users/henriksj/OneDrive%20-%20USN/Proskjet%20webapp%20gruppe%202/Forside.html">Priser</a>
							<a class="dropdown-item" href="file:///Users/henriksj/OneDrive%20-%20USN/Proskjet%20webapp%20gruppe%202/Forside.html">Prøvetid </a>
							<a class="dropdown-item" href="file:///Users/henriksj/OneDrive%20-%20USN/Proskjet%20webapp%20gruppe%202/Forside.html">side</a>
							<a class="dropdown-item" href="file:///Users/henriksj/OneDrive%20-%20USN/Proskjet%20webapp%20gruppe%202/Forside.html">side</a>

						</div>
					</li>


			
				

	
					<li class="nav-item">
						<a class="nav-link" href="file:///Users/henriksj/OneDrive%20-%20USN/Proskjet%20webapp%20gruppe%202/Forside.html">Om appen</a>
					</li>
				
					
					<li class="nav-item">
						<a class="nav-link" href="http://192.168.64.2/%20gruppe2/Feedback.html">Feedback</a>
					</li>
					
					<li class="nav-item">
						<a class="nav-link" href="http://192.168.64.2/%20gruppe2/Login.html">Logg inn</a>
					</li>
					<li class="nav-item">
						<a class="nav-link" href="http://192.168.64.2/%20gruppe2/Signup.html">Registrer deg</a>
					</li>
					<li class="nav-item">
						<a class="nav-link" href="http://192.168.64.2/%20gruppe2/Dashbord.html">dashbord</a>
					</li>
				
				
				</ul>
			</div>