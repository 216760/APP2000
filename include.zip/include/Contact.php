<div class="section4">
						
		<div class="col-md-5 text-center">
					<img src="img/Logo.png">
											
				<p>(+47) ### ## ###<br>email@abonnent-appen.com</p>
				<a href="http://facebook.com" target="_blank"><i class="fab fa-facebook-square"></i></a>
				<a href="http://twiter.com" target="_blank"><i class="fab fa-twitter-square"></i></a>
				<a href="http://instagram.com" target="_blank"><i class="fab fa-instagram"></i></a>
		</div>
			<hr class="socket">
			&copy; abonnent-appen

</div>
				